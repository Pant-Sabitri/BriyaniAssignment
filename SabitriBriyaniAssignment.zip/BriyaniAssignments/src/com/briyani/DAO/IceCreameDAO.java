package com.briyani.DAO;

public interface IceCreameDAO {
	
	int VanillaTotal();
	int ChocolateTotal();

}
