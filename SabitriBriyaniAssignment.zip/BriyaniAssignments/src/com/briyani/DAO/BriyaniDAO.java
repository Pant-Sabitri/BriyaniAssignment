package com.briyani.DAO;

public interface BriyaniDAO {
	
	int ChickenBriyani();
	int VegBriyani();
	int FishBriyani();

}
