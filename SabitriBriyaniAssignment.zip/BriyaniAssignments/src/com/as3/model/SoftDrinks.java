package com.as3.model;

public class SoftDrinks {
	
	private String sprite;
	private final int sprite_price = 10;
	private String ThumsUp;
	private final int ThumsUp_price = 5;
	
	public SoftDrinks() {
		
	}
	public SoftDrinks(String sprite, String thumsUp) {
		super();
		this.sprite = sprite;
		ThumsUp = thumsUp;
	}
	public String getSprite() {
		return sprite;
	}
	public int getSprite_price() {
		return sprite_price;
	}
	public String getThumsUp() {
		return ThumsUp;
	}
	public int getThumsUp_price() {
		return ThumsUp_price;
	}
	public void setSprite(String sprite) {
		this.sprite = sprite;
	}
	public void setThumsUp(String thumsUp) {
		ThumsUp = thumsUp;
	}
	
}
