package briyaniDetails;

import java.util.Scanner;

import ImplementationOFInterface.BriyaniImpl;

public class BriyaniDetails {
	
	Scanner sc = new Scanner (System.in);

	public int TotalBriyaniBill = 0;
	
	public void briyaniDetails() {
		BriyaniImpl briyaniImpl = new BriyaniImpl();
		
	while(true) 
	{
		System.out.println("*********************************************************");
		System.out.println("************** 1). ChickenBn *******************************");
		System.out.println("************** 2). VegBn *******************************");
		System.out.println("************** 3). FishBn ******************************");
		System.out.println("************** 4). Back    *******************************");
		System.out.println("*********************************************************");
		
		System.out.println("Choose an option from above list!");
		int choice = sc.nextInt();
		
		switch(choice){
		
		case 1: 
			 TotalBriyaniBill = TotalBriyaniBill + briyaniImpl.ChickenBriyani();
			 System.out.println(" Total briyani bill is " + TotalBriyaniBill);
			
		case 2:
		 TotalBriyaniBill = TotalBriyaniBill + briyaniImpl.VegBriyani();
		 System.out.println(" Total briyani bill is " + TotalBriyaniBill);
		case 3:
			
			TotalBriyaniBill = TotalBriyaniBill + briyaniImpl.FishBriyani();
			 System.out.println(" Total briyani bill is " + TotalBriyaniBill);
		case 4:
			 System.out.println(" Back");
			
			default: 
				System.out.println("Choose 1 to 4 only!");	
				
		} // end of switch case
		
		
	} // end of while loop
	
	
	}

}
