package ImplementationOFInterface;

import java.util.Scanner;

import com.as3.model.HotDrinks;
import com.as3.model.SoftDrinks;
import com.briyani.DAO.DrinksDAO;

public class DrinksImpl implements DrinksDAO {

	SoftDrinks softDrinks = new SoftDrinks();
	HotDrinks hotDrinks = new HotDrinks();
	Scanner sc = new Scanner (System.in);
	
	public int softDrinksTotal() {
		
	System.out.println("How many number of sprite  you want?");
	int sprite = sc.nextInt();
	
	System.out.println("How many number of thumpsUp  you want?");
	int ThumsUp = sc.nextInt();
	
	int total_softDrinks_price = (softDrinks.getSprite_price()* sprite) + (softDrinks.getThumsUp_price() * ThumsUp) ;
		return total_softDrinks_price;
	}
	public int HotDrinksTotal() {
		System.out.println("How many cups of Tea you want?");
		int Tea = sc.nextInt();
		
		System.out.println("How many coffee  you want?");
		int coffee = sc.nextInt();
		
		int total_softDrinks_price = (hotDrinks.getTea_price()* Tea) + (hotDrinks.getCoffee_price() * coffee) ;
			return total_softDrinks_price;	}
}
