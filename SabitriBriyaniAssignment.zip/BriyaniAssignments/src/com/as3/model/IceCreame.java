package com.as3.model;

public class IceCreame {
	
	private String Vanilla;
	private final int Vanilla_Price = 10;
	
	private String Chocolate;
	private final int Chocolate_Price = 8;
	
	public IceCreame() {
		
	}
	public IceCreame(String vanilla, String chocolate) {
		super();
		Vanilla = vanilla;
		Chocolate = chocolate;
	}
	public String getVanilla() {
		return Vanilla;
	}
	public int getVanilla_Price() {
		return Vanilla_Price;
	}
	public String getChocolate() {
		return Chocolate;
	}
	public int getChocolate_Price() {
		return Chocolate_Price;
	}
	public void setVanilla(String vanilla) {
		Vanilla = vanilla;
	}
	public void setChocolate(String chocolate) {
		Chocolate = chocolate;
	}
	
}