package ImplementationOFInterface;

import java.util.Scanner;

import com.as3.model.Briyani;
import com.briyani.DAO.BriyaniDAO;

public class BriyaniImpl implements BriyaniDAO{

	Briyani briyani = new Briyani();
	Scanner sc = new Scanner(System.in);
	public int ChickenBriyani() {
		
		System.out.println("How many number of chicken briyani plates do you want?");
		int Plate = sc.nextInt();
	    int Total_Chn_Bn_price = briyani.getChkenBn_Price() * Plate;
	    return Total_Chn_Bn_price;
		 
	}
	public int VegBriyani() {
		System.out.println("How many number of veg briyani plates do you want?");
		int Plate = sc.nextInt();
	    int Total_Veg_Bn_price = briyani.getVegBn_Price() * Plate;
	    return Total_Veg_Bn_price;
	}
	public int FishBriyani() {
		System.out.println("How many number of Fish briyani plates do you want?");
		int Plate = sc.nextInt();
	    int Total_Fish_Bn_price = briyani.getFishBn_Price() * Plate;
	    return Total_Fish_Bn_price;
	}
}
