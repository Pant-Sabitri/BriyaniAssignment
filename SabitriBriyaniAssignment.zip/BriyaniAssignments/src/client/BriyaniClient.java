package client;

import java.util.Scanner;

import briyaniDetails.BriyaniDetails;
import briyaniDetails.HotDrinksDetails;
import briyaniDetails.IceCream;
import briyaniDetails.SoftDrinksDetails;

public class BriyaniClient {

	public static void main(String[] args) {

		Scanner sc = new Scanner (System.in);
		
		SoftDrinksDetails softDrinks = new SoftDrinksDetails();
		IceCream iceCream = new IceCream();
		HotDrinksDetails hotDrinks = new HotDrinksDetails();
		BriyaniDetails briyaniDetails = new BriyaniDetails();
		while(true) {
			System.out.println("*********************************************************");
			System.out.println("************** 1). Briyani *******************************");
			System.out.println("************** 2). Drinks *******************************");
			System.out.println("************** 3). IceCream ******************************");
			System.out.println("************** 4). Bill    *******************************");
			System.out.println("************** 5). Exit    *******************************");
			System.out.println("*********************************************************");
			
			System.out.println("Choose an option! listed above!");
			int choice = sc.nextInt();
			
			switch(choice){
			
			case 1:
				 briyaniDetails.briyaniDetails();
				 break;
			case 2:
				hotDrinks.hotDrinksdetails();
				 break;
			case 3:
				iceCream.IceCreamDetails();
				 break;
			case 4:
				 System.out.println("Your total bill is: " + (iceCream.total_iceCream_Bill + softDrinks.total_SoftDrinks_Bill + hotDrinks.total_hotDrinks + briyaniDetails.TotalBriyaniBill));
				 break;
			case 5:
				
				default: 
					System.out.println("Choose 1 to 5 only!");	
					
			} // end of switch case
			
			
		} // end of while loop
	}

}
