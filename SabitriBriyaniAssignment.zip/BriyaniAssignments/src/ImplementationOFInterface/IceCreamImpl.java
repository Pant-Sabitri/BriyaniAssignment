package ImplementationOFInterface;

import java.util.Scanner;

import com.as3.model.IceCreame;
import com.briyani.DAO.IceCreameDAO;

public class IceCreamImpl implements IceCreameDAO{

	IceCreame iceCream = new IceCreame();
	Scanner sc = new Scanner (System.in);
	
	
	public int VanillaTotal() {
		
		System.out.println("How many number of vanilla you want?");
		int vanilla = sc.nextInt();
		int total_vanilla_price = (iceCream.getVanilla_Price()* vanilla); 
			return total_vanilla_price;	
	}
	
	public int ChocolateTotal() {
		
		System.out.println("How many number of Chocolate you want?");
		int Chocolate = sc.nextInt();
		int total_Chocolate_price = (iceCream.getChocolate_Price()* Chocolate) ;
			return total_Chocolate_price;	
	}
}
