package briyaniDetails;

import java.util.Scanner;

import ImplementationOFInterface.IceCreamImpl;

public class IceCream {

	Scanner sc = new Scanner (System.in);
public int total_iceCream_Bill =0;	
	
	public void IceCreamDetails() {
		
		IceCreamImpl iceCream = new IceCreamImpl();
		
		while(true) {
			System.out.println("*********************************************************");
			System.out.println("************** 1). Vanilla *******************************");
			System.out.println("************** 2). Chocolate *******************************");
			System.out.println("************** 3). Back    *******************************");
			System.out.println("*********************************************************");
			
			System.out.println("Choose an option from above list!");
			int choice = sc.nextInt();
			
			switch(choice){
			
			case 1: 
				total_iceCream_Bill += iceCream.VanillaTotal();
				System.out.println("total price of  ice cream is " + total_iceCream_Bill);
			case 2:
				total_iceCream_Bill += iceCream.ChocolateTotal();
				System.out.println("total price of  ice cream is " + total_iceCream_Bill);
			case 3:
				System.out.println("Back");
				default: 
					System.out.println("Choose 1 to 3 only!");	
					
			} // end of switch case
			
			
		} // end of while loop
}
}
