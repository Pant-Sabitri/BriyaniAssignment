package com.briyani.DAO;

public interface DrinksDAO {
	
	int softDrinksTotal();
	int HotDrinksTotal();

}
