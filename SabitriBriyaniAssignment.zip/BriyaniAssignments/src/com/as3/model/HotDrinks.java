package com.as3.model;

public class HotDrinks {

	private String Tea;
	private final int Tea_price = 5;
	private String Coffee;
	private final int Coffee_price = 6;
	
	
	public HotDrinks() {
		
	}
	public HotDrinks(String tea, String coffee) {
		super();
		Tea = tea;
		Coffee = coffee;
	}
	public String getTea() {
		return Tea;
	}
	public int getTea_price() {
		return Tea_price;
	}
	public String getCoffee() {
		return Coffee;
	}
	public int getCoffee_price() {
		return Coffee_price;
	}
	public void setTea(String tea) {
		Tea = tea;
	}
	public void setCoffee(String coffee) {
		Coffee = coffee;
	}
	
}


