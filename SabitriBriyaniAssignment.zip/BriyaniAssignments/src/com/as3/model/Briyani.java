package com.as3.model;

public class Briyani {
	
	private String chickenBn;
	private final int chkenBn_Price = 30;
	
	private String VegBn;
	private final int VegBn_Price = 20;
	
	private String FishBn;
	private final int FishBn_Price = 25;
	
	
	public Briyani() {
		
	}
	
	public Briyani(String chickenBn, String vegBn, String fishBn) {
		super();
		this.chickenBn = chickenBn;
		VegBn = vegBn;
		FishBn = fishBn;
	}
	public String getChickenBn() {
		return chickenBn;
	}
	public int getChkenBn_Price() {
		return chkenBn_Price;
	}
	public String getVegBn() {
		return VegBn;
	}
	public int getVegBn_Price() {
		return VegBn_Price;
	}
	public String getFishBn() {
		return FishBn;
	}
	public int getFishBn_Price() {
		return FishBn_Price;
	}
	public void setChickenBn(String chickenBn) {
		this.chickenBn = chickenBn;
	}
	public void setVegBn(String vegBn) {
		VegBn = vegBn;
	}
	public void setFishBn(String fishBn) {
		FishBn = fishBn;
	}
	
	

}
